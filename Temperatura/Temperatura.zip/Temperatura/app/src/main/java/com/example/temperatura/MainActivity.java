package com.example.temperatura;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import java.lang.*;




public class MainActivity extends AppCompatActivity {
    EditText valor;
    TextView resposta;
    Button b1, b2, b3, b4;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        resposta = (TextView)findViewById(R.id.resposta);
        valor =  (EditText) findViewById(R.id.valor);
        b1 = (Button) findViewById(R.id.b1);
        b2 = (Button) findViewById(R.id.b2);
        b3 = (Button) findViewById(R.id.b3);
        b4 = (Button) findViewById(R.id.b4);

        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                double kelvin = Double.parseDouble(valor.getText().toString()) + 273.15;
                resposta.setText(String.valueOf(kelvin)+"K");
            }
        });

        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                double fahrenheit = Double.parseDouble(valor.getText().toString()) * 1.8 + 32;
                resposta.setText(String.valueOf(fahrenheit+"Â°F"));
            }
        });

        b3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                double reamur = Double.parseDouble(valor.getText().toString()) * 4 / 5;
                resposta.setText(String.valueOf(reamur+"Â°R"));
            }
        });

        b4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                double rankine = Double.parseDouble(valor.getText().toString());
                double rankine1 = (rankine + 273.15) * 9 / 5;
                resposta.setText(String.format("%.2fÂ°",rankine1));
            }
        });


    }

}
