package natalia.pratica07;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Base64;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;


public class MainActivity extends AppCompatActivity {

    private Button buttonSalvar;
    private EditText editTextNome;
    private EditText editTextEmail;
    private EditText editTextCEP;
    private EditText editTextEnd;
    private EditText editTextTel;
    private EditText editTextData;
    private Button buttonEditar;
    private Button buttonListar;
    private DatabaseReference databaseReference = FirebaseDatabase.getInstance().getReference();
    private DatabaseReference contaoDatabaseReference = databaseReference.child("Contatos");

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        buttonSalvar = (Button) findViewById(R.id.button_salvar_id);
        editTextNome = (EditText) findViewById(R.id.editText_nome_id);
        editTextEmail = (EditText) findViewById(R.id.editText_email_id);
        editTextCEP = (EditText) findViewById(R.id.editText_cep_id);
        editTextEnd = (EditText) findViewById(R.id.editText_end_id);
        editTextTel = (EditText) findViewById(R.id.editText_telefone_id);
        editTextData = (EditText) findViewById(R.id.editText_datanasc_id);
        buttonEditar = (Button) findViewById(R.id.button_editar_id);
        buttonListar = (Button) findViewById(R.id.button_listar_id);
        buttonSalvar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String nome = editTextNome.getText().toString();
                String email = editTextEmail.getText().toString();
                String cep = editTextCEP.getText().toString();
                String endereco = editTextEnd.getText().toString();
                String telefone = editTextTel.getText().toString();
                String data = editTextData.getText().toString();
                if ((nome != "") && (email != "")) {
                    Contato pessoa = new Contato(nome, email);
                    pessoa.setCep(cep);
                    pessoa.setEndereco(endereco);
                    pessoa.setTelefone(telefone);
                    pessoa.setData(data);
                    cadastrarUsuarios(pessoa);
                    Toast.makeText(getApplicationContext(), "Contato cadastrado com sucesso", Toast.LENGTH_SHORT).show();
                }
                editTextNome.setText("");
                editTextEmail.setText("");
                editTextCEP.setText("");
                editTextEnd.setText("");
                editTextTel.setText("");
                editTextData.setText("");
            }
        });
        buttonListar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, Listar.class));
            }
        });
        buttonEditar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, Editar.class));
            }
        });
    }

    private void cadastrarUsuarios(final Contato pessoa) {
        contaoDatabaseReference.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                String idContato = Base64.encodeToString(pessoa.getEmail().getBytes(), Base64.DEFAULT).replaceAll("(\\n|\\r)", "");
                pessoa.setId(idContato);
                boolean contatoJaCadastrado = dataSnapshot.hasChild(idContato);
                if (contatoJaCadastrado)
                    Toast.makeText(getApplicationContext(), "Contato já cadastrado anteriormente.", Toast.LENGTH_SHORT).show();
                else {
                    contaoDatabaseReference.child(idContato).setValue(pessoa);
                }
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {
            }
        });
    }
}