package natalia.pratica07;

public class Contato {
    private String id;
    private String nome;
    private String email;
    private String endereco;
    private String cep;
    private String telefone;
    private String data;
    public Contato (String nome, String email) {
        this.nome = nome;
        this.email = email;
    }
    public Contato () { }
    @Override
    public String toString() {
        return "Nome: " + nome + "\n"
                + "E-mail: " + email + "\n"
                + "Endereço: " + endereco + "\n"
                + "CEP: " + cep + "\n"
                + "Telefone: " + telefone + "\n"
                + "Data de Nascimento: " + data + "\n";
    }
    public String getId() {
        return id;
    }
    public void setId(String id) {
        this.id = id;
    }
    public String getNome() {
        return nome;
    }
    public void setNome(String nome) {
        this.nome = nome;
    }
    public String getEmail() {
        return email;
    }
    public void setEmail(String email) {
        this.email = email;
    }
    public String getEndereco() {
        return endereco;
    }
    public void setEndereco(String endereco) {
        this.endereco = endereco;
    }
    public String getCep() {
        return cep;
    }
    public void setCep(String cep) {
        this.cep = cep;
    }
    public String getTelefone(){
        return telefone;
    }
    public void setTelefone(String telefone){
        this.telefone = telefone;
    }
    public String getData(){
        return data;
    }
    public void setData(String data){
        this.data = data;
    }
}
