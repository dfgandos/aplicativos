package natalia.pratica07;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Base64;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class Editar extends AppCompatActivity {
    private Button buttonBuscar;
    private EditText editTextNome;
    private EditText editTextEmail;
    private Button buttonAtualizar;
    private Button buttonDeletar;
    private EditText editTextUserId;
    private EditText editTextEnd;
    private EditText editTextCEP;
    private EditText editTextTel;
    private EditText editTextData;
    private DatabaseReference databaseReference = FirebaseDatabase.getInstance().getReference();
    private DatabaseReference contaoDatabaseReference = databaseReference.child("Contatos");

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_editar);
        buttonBuscar = (Button) findViewById(R.id.button_buscar_id);
        editTextNome = (EditText) findViewById(R.id.editText_nome_id);
        editTextEmail = (EditText) findViewById(R.id.editText_email_id);
        buttonAtualizar = (Button) findViewById(R.id.button_atualizar_id);
        buttonDeletar = (Button) findViewById((R.id.button_delete_id));
        editTextUserId = (EditText) findViewById(R.id.editText_iduser_id);
        editTextCEP = (EditText) findViewById(R.id.editText_cep_id);
        editTextEnd = (EditText) findViewById(R.id.editText_end_id);
        editTextTel = (EditText) findViewById(R.id.editText_telefone_id);
        editTextData = (EditText) findViewById(R.id.editText_datanasc_id);
        buttonBuscar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final String email_id = editTextUserId.getText().toString();
                contaoDatabaseReference.addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(DataSnapshot dataSnapshot) {
                        Contato contato = new Contato();
                        String idContato = Base64.encodeToString(email_id.getBytes(), Base64.DEFAULT).replaceAll("(\\n|\\r)", "");
                        boolean contatoCadastrado = dataSnapshot.hasChild(idContato);
                        if (contatoCadastrado) {
                            contato.setNome(dataSnapshot.child(idContato).child("nome").getValue().toString());
                            contato.setEmail(dataSnapshot.child(idContato).child("email").getValue().toString());
                            contato.setId(dataSnapshot.child(idContato).child("id").getValue().toString());
                            contato.setCep(dataSnapshot.child(idContato).child("cep").getValue().toString());
                            contato.setEndereco(dataSnapshot.child(idContato).child("endereco").getValue().toString());
                            contato.setTelefone(dataSnapshot.child(idContato).child("telefone").getValue().toString());
                            contato.setData(dataSnapshot.child(idContato).child("data").getValue().toString());
                        } else {
                            contato = null;
                        }
                        if (contato != null) {
                            editTextNome.setText(contato.getNome());
                            editTextEmail.setText(contato.getEmail());
                            editTextCEP.setText(contato.getCep());
                            editTextEnd.setText(contato.getEndereco());
                            editTextTel.setText(contato.getTelefone());
                            editTextData.setText(contato.getData());
                        } else
                            Toast.makeText(getApplicationContext(), "Usuário não encontrado.", Toast.LENGTH_SHORT).show();
                    }

                    @Override
                    public void onCancelled(DatabaseError databaseError) {
                    }
                });
            }
        });
        buttonAtualizar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String email_id = editTextUserId.getText().toString();
                String nome = editTextNome.getText().toString();
                String email = editTextEmail.getText().toString();
                String cep = editTextCEP.getText().toString();
                String endereco = editTextEnd.getText().toString();
                String telefone = editTextTel.getText().toString();
                String data = editTextData.getText().toString();
                String idContato = Base64.encodeToString(email.getBytes(), Base64.DEFAULT).replaceAll("(\\n|\\r)", "");
                Contato contato = new Contato(nome, email);
                contato.setCep(cep);
                contato.setEndereco(endereco);
                contato.setTelefone(telefone);
                contato.setData(data);
                contato.setId(idContato);
                atualizaUsuarios(contato, email_id);
                editTextNome.setText("");
                editTextEmail.setText("");
                editTextCEP.setText("");
                editTextEnd.setText("");
                editTextTel.setText("");
                editTextData.setText("");
                editTextUserId.setText("");
            }
        });
        buttonDeletar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String email = editTextUserId.getText().toString();
                deleteUsuarios(email);
                editTextNome.setText("");
                editTextEmail.setText("");
                editTextCEP.setText("");
                editTextEnd.setText("");
                editTextTel.setText("");
                editTextData.setText("");
                editTextUserId.setText("");
            }
        });
    }

    private void atualizaUsuarios(final Contato contato, final String email_id) {
        contaoDatabaseReference.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                String idContato = contato.getId();
                boolean contatoJaCadastrado = dataSnapshot.hasChild(idContato);
                if (!contatoJaCadastrado) {
                    String idContatoAntigo = Base64.encodeToString(email_id.getBytes(), Base64.DEFAULT).replaceAll("(\\n|\\r)", "");
                    contaoDatabaseReference.child(idContatoAntigo).removeValue();
                    contaoDatabaseReference.child(idContato).setValue(contato);
                    Toast.makeText(getApplicationContext(), "Contato atualizado com sucesso", Toast.LENGTH_SHORT).show();
                } else {
                    contaoDatabaseReference.child(idContato).setValue(contato);
                    Toast.makeText(getApplicationContext(), "Contato atualizado com sucesso", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {
            }
        });
    }

    private void deleteUsuarios(final String email) {
        contaoDatabaseReference.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                String idContato = Base64.encodeToString(email.getBytes(), Base64.DEFAULT).replaceAll("(\\n|\\r)", "");
                boolean contatoExiste = dataSnapshot.hasChild(idContato);
                if (!contatoExiste)
                    Toast.makeText(getApplicationContext(), "Conato não existe.", Toast.LENGTH_SHORT).show();
                else {
                    contaoDatabaseReference.child(idContato).removeValue();
                    Toast.makeText(getApplicationContext(), "Contato removido com sucesso.", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {
            }
        });
    }
}