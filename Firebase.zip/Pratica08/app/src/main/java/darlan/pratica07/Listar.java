package natalia.pratica07;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

public class Listar extends AppCompatActivity {
    private DatabaseReference databaseReference = FirebaseDatabase.getInstance().getReference();
    private DatabaseReference contaoDatabaseReference = databaseReference.child("Contatos");
    private ListView listView;
    private Button botaoAtualizar;
    private ArrayAdapter<Contato> adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_listar);
        List<Contato> contatos;
        listView = (ListView) findViewById(R.id.listView_id);
        botaoAtualizar = (Button) findViewById(R.id.button_atualizar_id);
        botaoAtualizar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                listView.setAdapter(null);
                contaoDatabaseReference.addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(DataSnapshot dataSnapshot) {
                        List<Contato> contatos = new ArrayList<Contato>();
                        int num = 0;
                        for (DataSnapshot postSnapshot : dataSnapshot.getChildren()) {
                            Contato contato = new Contato();
                            contato.setNome(postSnapshot.child("nome").getValue().toString());
                            contato.setEmail(postSnapshot.child("email").getValue().toString());
                            contato.setCep(postSnapshot.child("cep").getValue().toString());
                            contato.setEndereco(postSnapshot.child("endereco").getValue().toString());
                            contato.setTelefone(postSnapshot.child("telefone").getValue().toString());
                            contato.setData(postSnapshot.child("data").getValue().toString());
                            contatos.add(contato);
                            contato = null;
                        }
                        adapter = new ArrayAdapter<Contato>(getApplicationContext(), android.R.layout.simple_list_item_1, contatos);
                        listView.setAdapter(adapter);
                    }

                    @Override
                    public void onCancelled(DatabaseError databaseError) {
                    }
                });
            }
        });
    }
}